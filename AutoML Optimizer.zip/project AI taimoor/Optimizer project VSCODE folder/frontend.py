import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk
import pandas as pd

from backend import backend_core   


df = None
selected_target = None
plot_images = []


# =================================================================
# LOGGING
# =================================================================
def log_output(text):
    output_box.insert(tk.END, text + "\n")
    output_box.see(tk.END)


# =================================================================
# CSV UPLOAD
# =================================================================
def upload_csv():
    global df

    file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    if not file_path:
        return

    df = pd.read_csv(file_path)
    file_label.config(text=file_path)

    cols = backend_core.load_csv_to_backend(df)
    target_dropdown["values"] = cols
    log_output("CSV loaded successfully.")


# =================================================================
# TARGET SELECTION
# =================================================================
def on_target_selected(e):
    global selected_target
    selected_target = target_dropdown.get()

    backend_core.set_target_column(selected_target)
    log_output(f"Target selected: {selected_target}")


# =================================================================
# RUN AUTOML
# =================================================================
def start_automl():

    if df is None:
        log_output("Error: Load CSV first.")
        return

    desc = str(desc_box.get("1.0", tk.END).strip())

    log_output("Running AutoML... please wait.")

    result = backend_core.run_automl_backend(desc)

    if "error" in result:
        log_output("\nERROR OCCURRED:\n" + result["error"])
        return

    log_output(result["message"])
    log_output("\n--- Pipeline Output ---\n")
    log_output(result["text"])

    # SHOW PLOTS
    show_plots(result["plots"])

    log_output(f"\nZIP Report Saved At:\n{result['zip_path']}")


# =================================================================
# SHOW PLOTS IN GUI
# =================================================================
def show_plots(paths):
    global plot_images

    for w in plot_frame.winfo_children():
        w.destroy()

    plot_images = []

    for p in paths:
        try:
            img = Image.open(p)
            img = img.resize((260, 200))
            tk_img = ImageTk.PhotoImage(img)
            plot_images.append(tk_img)

            lbl = tk.Label(plot_frame, image=tk_img)
            lbl.pack(side="left", padx=10)
        except:
            pass


# =================================================================
# TKINTER UI
# =================================================================
root = tk.Tk()
root.title("AutoML Desktop App")
root.geometry("1100x700")


# Top frame: Upload CSV
upload_fr = tk.Frame(root)
upload_fr.pack(fill="x", padx=10, pady=10)

tk.Button(upload_fr, text="Upload CSV", command=upload_csv).pack(side="left")
file_label = tk.Label(upload_fr, text="No file selected")
file_label.pack(side="left", padx=10)


# Description Box
desc_fr = tk.Frame(root)
desc_fr.pack(fill="x", padx=10, pady=10)

tk.Label(desc_fr, text="Describe what you want to predict:").pack(anchor="w")
desc_box = tk.Text(desc_fr, height=4)
desc_box.pack(fill="x")


# Target Column
target_fr = tk.Frame(root)
target_fr.pack(fill="x", padx=10, pady=10)

tk.Label(target_fr, text="Select Target Column (optional):").pack(anchor="w")
target_dropdown = ttk.Combobox(target_fr, state="readonly")
target_dropdown.pack(fill="x")
target_dropdown.bind("<<ComboboxSelected>>", on_target_selected)


# Run Button
tk.Button(root, text="Run AutoML", command=start_automl).pack(pady=10)


# Plot Output Frame
plot_frame = tk.Frame(root, height=220)
plot_frame.pack(fill="x", padx=10, pady=10)


# Log Output
log_fr = tk.Frame(root)
log_fr.pack(fill="both", expand=True, padx=10, pady=10)

tk.Label(log_fr, text="Output Log:").pack(anchor="w")
output_box = tk.Text(log_fr, height=14)
output_box.pack(fill="both", expand=True)


root.mainloop()
