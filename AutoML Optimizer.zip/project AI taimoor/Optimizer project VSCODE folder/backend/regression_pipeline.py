# ========================================================================
#   regression_pipeline.py (FINAL, CLEAN, FULLY SYNCED VERSION)
# ========================================================================

import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import r2_score, mean_squared_error

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor


# ========================================================================
# PREPROCESSOR
# ========================================================================
def preprocess_regression(df, target_column, keep_columns=None):

    df = df.copy()

    if keep_columns is not None:
        df = df[keep_columns + [target_column]]

    # Drop 80% missing columns
    drop_missing = [c for c in df.columns if df[c].isna().mean() >= 0.80]
    df.drop(columns=drop_missing, inplace=True)

    # Drop big-cardinality text
    drop_high_card = [
        c for c in df.columns
        if df[c].dtype == "object" and df[c].nunique() > 100
    ]
    df.drop(columns=drop_high_card, inplace=True)

    # Boolean → int
    for c in df.columns:
        if df[c].dtype == bool:
            df[c] = df[c].astype(int)

    # Fill missing
    for c in df.columns:
        if c == target_column:
            continue

        if df[c].dtype in ["int64", "float64"]:
            df[c].fillna(df[c].median(), inplace=True)
        else:
            df[c].fillna(df[c].mode()[0], inplace=True)

    # Label encode categoricals
    for c in df.columns:
        if df[c].dtype == "object":
            df[c] = LabelEncoder().fit_transform(df[c])

    X = df.drop(columns=[target_column])
    y = df[target_column]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # scale
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    return X_train_s, X_test_s, y_train, y_test, X.columns.tolist()



# ========================================================================
# BASELINE MODELS
# ========================================================================
def run_linear_baseline(Xtr, ytr, Xte, yte):
    model = LinearRegression()
    model.fit(Xtr, ytr)
    preds = model.predict(Xte)

    r2 = r2_score(yte, preds)
    rmse = np.sqrt(mean_squared_error(yte, preds))   # <-- FIXED

    return model, r2, rmse


def run_rf_baseline(Xtr, ytr, Xte, yte):
    model = RandomForestRegressor(
        n_estimators=300,
        max_depth=None,
        random_state=42
    )
    model.fit(Xtr, ytr)
    preds = model.predict(Xte)

    r2 = r2_score(yte, preds)
    rmse = np.sqrt(mean_squared_error(yte, preds))   # <-- FIXED

    return model, r2, rmse


def run_xgb_baseline(Xtr, ytr, Xte, yte):
    model = XGBRegressor(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="reg:squarederror",
        eval_metric="rmse",
        random_state=42
    )
    model.fit(Xtr, ytr)
    preds = model.predict(Xte)

    r2 = r2_score(yte, preds)
    rmse = np.sqrt(mean_squared_error(yte, preds))   # <-- FIXED

    return model, r2, rmse



# ========================================================================
# BALANCED XGBOOST OPTIMIZER
# ========================================================================
def optimize_xgboost(Xtr, ytr, Xte, yte):

    grid = {
        "n_estimators": [300, 500],
        "max_depth": [4, 6, 8],
        "learning_rate": [0.03, 0.05, 0.1],
        "subsample": [0.8, 1.0],
        "colsample_bytree": [0.8, 1.0],
    }

    best_r2 = -999
    best_model = None
    best_params = None

    cv = KFold(n_splits=3, shuffle=True, random_state=42)

    for n in grid["n_estimators"]:
        for d in grid["max_depth"]:
            for lr in grid["learning_rate"]:
                for ss in grid["subsample"]:
                    for cs in grid["colsample_bytree"]:

                        params = {
                            "n_estimators": n,
                            "max_depth": d,
                            "learning_rate": lr,
                            "subsample": ss,
                            "colsample_bytree": cs,
                            "objective": "reg:squarederror",
                            "eval_metric": "rmse",
                            "random_state": 42
                        }

                        m = XGBRegressor(**params)

                        scores = cross_val_score(
                            m, Xtr, ytr, scoring="r2", cv=cv
                        )
                        mean_r2 = scores.mean()

                        if mean_r2 > best_r2:
                            best_r2 = mean_r2
                            best_params = params

    final_model = XGBRegressor(**best_params)
    final_model.fit(Xtr, ytr)

    preds = final_model.predict(Xte)
    final_r2 = r2_score(yte, preds)

    return final_model, best_params, final_r2



# ========================================================================
# MAIN PIPELINE (RETURN FORMAT SYNCED WITH backend_core)
# ========================================================================
def run_regression_pipeline(df, target_column):

    text = "\n=== REGRESSION PIPELINE START ===\n\n"

    Xtr, Xte, ytr, yte, feature_names = preprocess_regression(df, target_column)

    # Baselines
    lin_model, lin_r2, lin_rmse = run_linear_baseline(Xtr, ytr, Xte, yte)
    rf_model, rf_r2, rf_rmse = run_rf_baseline(Xtr, ytr, Xte, yte)
    xgb_model, xgb_r2, xgb_rmse = run_xgb_baseline(Xtr, ytr, Xte, yte)

    text += f"LinearRegression: R2={lin_r2:.4f}, RMSE={lin_rmse:.4f}\n"
    text += f"RandomForest:    R2={rf_r2:.4f}, RMSE={rf_rmse:.4f}\n"
    text += f"XGBoost:         R2={xgb_r2:.4f}, RMSE={xgb_rmse:.4f}\n\n"

    # Select best
    scores = {
        "LinearRegression": lin_r2,
        "RandomForest": rf_r2,
        "XGBoost": xgb_r2
    }
    best_name = max(scores.items(), key=lambda x: x[1])[0]

    text += f"Best Baseline: {best_name}\n\n"

    # Optimize
    if best_name == "XGBoost":
        best_model, best_params, best_r2 = optimize_xgboost(Xtr, ytr, Xte, yte)
    elif best_name == "RandomForest":
        best_model = rf_model
        best_params = {"n_estimators": 300, "max_depth": None}
        best_r2 = rf_r2
    else:
        best_model = lin_model
        best_params = {}
        best_r2 = lin_r2

    text += f"Optimized R2: {best_r2:.4f}\n"
    text += f"Best Params: {best_params}\n"
    text += "\n=== REGRESSION PIPELINE END ===\n"

    # IMPORTANT: return EXACTLY what backend_core expects
    return text, best_model, Xte, yte, feature_names
