# ============================================================
# IMPORTS
# ============================================================
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.inspection import permutation_importance

from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier


# ============================================================
# PREPROCESSING
# ============================================================
def preprocess_classification(df, target_column, keep_columns=None):
    df = df.copy()

    # If pruning feature-selection is applied:
    if keep_columns is not None:
        keep_cols = keep_columns + [target_column]
        df = df[[c for c in df.columns if c in keep_cols]]

    # Drop columns with too many missing values
    missing_cols = [c for c in df.columns if df[c].isna().mean() >= 0.80]
    df.drop(columns=missing_cols, inplace=True)

    # Drop extremely high-cardinality categories
    high_card_cols = [c for c in df.columns if df[c].dtype == "object" and df[c].nunique() > 100]
    df.drop(columns=high_card_cols, inplace=True)

    # Convert booleans
    for col in df.columns:
        if df[col].dtype == bool:
            df[col] = df[col].astype(int)

    # Impute missing
    for col in df.columns:
        if df[col].dtype in ["int64", "float64"]:
            df[col].fillna(df[col].median(), inplace=True)
        else:
            df[col].fillna(df[col].mode()[0], inplace=True)

    # Label encoding
    for col in df.columns:
        if df[col].dtype == "object":
            df[col] = LabelEncoder().fit_transform(df[col])

    X = df.drop(columns=[target_column])
    y = df[target_column]

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )

    # Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return X_train, X_test, X_train_scaled, X_test_scaled, y_train, y_test, list(X.columns)


# ============================================================
# BASELINES
# ============================================================
def run_knn_baseline(X_train_scaled, y_train, X_test_scaled, y_test):
    model = KNeighborsClassifier(n_neighbors=5, weights="distance")
    model.fit(X_train_scaled, y_train)
    acc = accuracy_score(y_test, model.predict(X_test_scaled))
    return model, acc


def run_rf_baseline(X_train, y_train, X_test, y_test):
    model = RandomForestClassifier(n_estimators=300, random_state=42)
    model.fit(X_train, y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    return model, acc


def run_nn_baseline(X_train_scaled, y_train, X_test_scaled, y_test):
    model = MLPClassifier(
        hidden_layer_sizes=(128, 64),
        learning_rate_init=0.001,
        max_iter=400,
        early_stopping=True,
        random_state=42
    )
    model.fit(X_train_scaled, y_train)
    acc = accuracy_score(y_test, model.predict(X_test_scaled))
    return model, acc


# ============================================================
# FEATURE IMPORTANCE HANDLER
# ============================================================
def compute_feature_importance(model, X_test, y_test, feature_names):

    # RF has native importance
    if isinstance(model, RandomForestClassifier):
        vals = model.feature_importances_
        ranks = list(zip(feature_names, vals))
        ranks.sort(key=lambda x: x[1], reverse=True)
        return ranks

    # KNN + NN use permutation importance
    perm = permutation_importance(model, X_test, y_test, n_repeats=3, random_state=42)
    vals = perm.importances_mean
    ranks = list(zip(feature_names, vals))
    ranks.sort(key=lambda x: x[1], reverse=True)
    return ranks


# ============================================================
# OPTIMIZERS
# ============================================================
def optimize_knn(X_train_scaled, y_train, X_test_scaled, y_test):
    best_acc = 0
    best_model = None
    best_params = {}

    for k in range(1, 22, 2):
        m = KNeighborsClassifier(n_neighbors=k, weights="distance")
        m.fit(X_train_scaled, y_train)
        acc = accuracy_score(y_test, m.predict(X_test_scaled))

        if acc > best_acc:
            best_acc = acc
            best_model = m
            best_params = {"k": k}

    return best_model, best_params, best_acc


def optimize_rf(X_train, y_train, X_test, y_test):

    n_vals = [100, 300, 500]
    depths = [None, 10, 20]
    splits = [2, 5]
    leaves = [1, 2]

    best_acc = 0
    best_model = None
    best_params = {}

    for n in n_vals:
        for d in depths:
            for s in splits:
                for l in leaves:

                    m = RandomForestClassifier(
                        n_estimators=n,
                        max_depth=d,
                        min_samples_split=s,
                        min_samples_leaf=l,
                        random_state=42
                    )
                    m.fit(X_train, y_train)

                    acc = accuracy_score(y_test, m.predict(X_test))

                    if acc > best_acc:
                        best_acc = acc
                        best_model = m
                        best_params = {
                            "n_estimators": n,
                            "max_depth": d,
                            "min_samples_split": s,
                            "min_samples_leaf": l
                        }

    return best_model, best_params, best_acc


def optimize_nn(X_train_scaled, y_train, X_test_scaled, y_test):

    layer_options = [(64, 32), (128, 64), (256, 128)]
    lr_options = [0.001, 0.0005]

    best_acc = 0
    best_model = None
    best_params = {}

    for layers in layer_options:
        for lr in lr_options:

            m = MLPClassifier(
                hidden_layer_sizes=layers,
                learning_rate_init=lr,
                max_iter=500,
                early_stopping=True,
                random_state=42
            )
            m.fit(X_train_scaled, y_train)
            acc = accuracy_score(y_test, m.predict(X_test_scaled))

            if acc > best_acc:
                best_acc = acc
                best_model = m
                best_params = {"layers": layers, "lr": lr}

    return best_model, best_params, best_acc


# ============================================================
# MAIN PIPELINE
# ============================================================
def run_classification_pipeline(df, target_column):

    text = "\n=== CLASSIFICATION PIPELINE START ===\n\n"

    X_train, X_test, X_train_scaled, X_test_scaled, y_train, y_test, feature_names = \
        preprocess_classification(df, target_column)

    # BASELINES
    knn_m, knn_acc = run_knn_baseline(X_train_scaled, y_train, X_test_scaled, y_test)
    rf_m, rf_acc = run_rf_baseline(X_train, y_train, X_test, y_test)
    nn_m, nn_acc = run_nn_baseline(X_train_scaled, y_train, X_test_scaled, y_test)

    baselines = {
        "KNN": knn_acc,
        "RandomForest": rf_acc,
        "NeuralNetwork": nn_acc
    }

    text += "-- Baseline Results --\n"
    for k, v in baselines.items():
        text += f"{k}: {v:.4f}\n"

    best_name = max(baselines, key=baselines.get)
    text += f"\nBest Baseline: {best_name}\n"

    # OPTIMIZATION
    if best_name == "KNN":
        opt_model, opt_params, opt_acc = optimize_knn(X_train_scaled, y_train, X_test_scaled, y_test)
    elif best_name == "RandomForest":
        opt_model, opt_params, opt_acc = optimize_rf(X_train, y_train, X_test, y_test)
    else:
        opt_model, opt_params, opt_acc = optimize_nn(X_train_scaled, y_train, X_test_scaled, y_test)

    text += f"\nOptimized Accuracy: {opt_acc:.4f}\n"
    text += f"Hyperparameters: {opt_params}\n"

    text += "\n=== CLASSIFICATION PIPELINE END ===\n"

    return text, opt_model, X_test, y_test, feature_names
