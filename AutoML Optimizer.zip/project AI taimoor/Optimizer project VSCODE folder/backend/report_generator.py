"""
report_generator.py
Creates TXT + HTML reports + ZIP archive.
"""

import os
import zipfile


# ---------------------------------------------------------------------
def generate_report_and_zip(text_log, task_type, target_column, plots, out_dir):
    os.makedirs(out_dir, exist_ok=True)

    # -----------------------------------------------------------------
    # BUILD TXT REPORT
    # -----------------------------------------------------------------
    txt_path = os.path.join(out_dir, "report.txt")
    with open(txt_path, "w", encoding="utf-8") as f:

        f.write("=== AUTO ML REPORT ===\n\n")
        f.write(f"Detected Problem Type: {task_type.upper()}\n")
        f.write(f"Target Column: {target_column}\n\n")

        f.write("=== MODEL LOG ===\n")
        f.write(text_log)
        f.write("\n\n=== END OF REPORT ===\n")

    # -----------------------------------------------------------------
    # BUILD HTML REPORT
    # -----------------------------------------------------------------
    html_path = os.path.join(out_dir, "report.html")
    with open(html_path, "w", encoding="utf-8") as f:

        f.write("<html><body>")
        f.write("<h1>AutoML Report</h1>")
        f.write(f"<h2>Task Type: {task_type}</h2>")
        f.write(f"<h3>Target Column: {target_column}</h3>")

        f.write("<h2>Model Logs</h2>")
        f.write("<pre style='background:#f0f0f0;padding:10px;'>")
        f.write(text_log)
        f.write("</pre>")

        f.write("<h2>Generated Plots</h2>")

        for p in plots:
            f.write(f"<img src='{p}' width='450'><br><br>")

        f.write("</body></html>")

    # -----------------------------------------------------------------
    # ZIP THE ENTIRE OUTPUT FOLDER
    # -----------------------------------------------------------------
    zip_path = os.path.join(out_dir, "AutoML_Report.zip")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for fname in os.listdir(out_dir):
            full = os.path.join(out_dir, fname)
            if os.path.isfile(full) and not fname.endswith(".zip"):
                zipf.write(full, arcname=fname)

    return zip_path
