import spacy
import re
from difflib import SequenceMatcher

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm")
except:
    nlp = None

def clean(text):
    # ensure we always get a usable string
    if not isinstance(text, str):
        try:
            text = " ".join(map(str, text))
        except:
            text = str(text)

    return re.sub(r'[^a-zA-Z0-9 ]+', '', text).lower().strip()


def detect_task_type(description, target_dtype=None, target_unique=None):

    desc = clean(description)
    doc = nlp(desc) if nlp else None

    regression_words = [
        "predict", "forecast", "estimate", "price", "value",
        "amount", "cost", "sales", "income", "score", "continuous"
    ]

    classification_words = [
        "classify", "category", "label", "yes", "no",
        "binary", "churn", "fraud", "default", "spam",
        "detect", "type", "segment"
    ]

    reg_score = sum(w in desc for w in regression_words)
    cls_score = sum(w in desc for w in classification_words)

    if target_dtype == "object" and target_unique and target_unique < 20:
        cls_score += 3
    if target_dtype in ["int64", "float64"] and target_unique and target_unique > 50:
        reg_score += 3

    if reg_score > cls_score:
        return "regression", (reg_score, cls_score)
    else:
        return "classification", (cls_score, reg_score)


def detect_target_column(description, columns):

    desc = clean(description)
    doc = nlp(desc) if nlp else None

    best_col = None
    best_score = -1

    for col in columns:
        col_clean = clean(col)

        fuzzy = SequenceMatcher(None, desc, col_clean).ratio()

        token_sim = nlp(col_clean).similarity(doc) if (doc and nlp) else 0

        final_score = 0.6 * fuzzy + 0.4 * token_sim

        if final_score > best_score:
            best_score = final_score
            best_col = col

    return best_col, best_score
