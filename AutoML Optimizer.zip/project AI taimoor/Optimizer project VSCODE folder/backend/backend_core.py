"""
backend_core.py
Main logic connecting GUI → NLP → pipelines → plotting → report.
"""

import os
import pandas as pd
import traceback

from backend.nlp_engine import detect_task_type, detect_target_column
from backend.regression_pipeline import run_regression_pipeline
from backend.classification_pipeline import run_classification_pipeline
from backend.plotting import generate_all_plots
from backend.report_generator import generate_report_and_zip


# --------------------------------------------------------------------------------------
# STORED STATE
# --------------------------------------------------------------------------------------
backend_df = None
backend_target = None


# --------------------------------------------------------------------------------------
# PUBLIC — Called by GUI
# --------------------------------------------------------------------------------------
def load_csv_to_backend(df):
    """Stores dataframe in backend memory."""
    global backend_df
    backend_df = df
    return df.columns.tolist()


def set_target_column(col):
    """Stores user-selected target column."""
    global backend_target
    backend_target = col
    return f"Target column '{col}' saved."


# --------------------------------------------------------------------------------------
# MAIN ENTRY — AutoML Pipeline
# --------------------------------------------------------------------------------------
def run_automl_backend(description_text):

    global backend_df, backend_target

    try:
        if backend_df is None:
            return {"error": "CSV not loaded"}

        df = backend_df.copy()

        
 # =====================================================================
# 1. Auto-detect target column
# =====================================================================
        if backend_target is None or backend_target.strip() == "":
            auto_col, score = detect_target_column(description_text, df.columns.tolist())

            if auto_col is None:
                return {"error": "Couldn't detect a target column. Please select manually."}

            backend_target = auto_col

        target_col = backend_target

# Column dtype info
        target_dtype = str(df[target_col].dtype)
        target_unique = df[target_col].nunique()

# =====================================================================
# 2. NLP → classification/regression decision
# =====================================================================
        task_type, nlp_info = detect_task_type(description_text, target_dtype, target_unique)


        # =====================================================================
        # 3. Run pipeline according to chosen task
        # =====================================================================
        if task_type == "regression":
            text_log, model, X_test, y_test, feature_names = \
                run_regression_pipeline(df, target_col)
        else:
            text_log, model, X_test, y_test, feature_names = \
                run_classification_pipeline(df, target_col)

        # =====================================================================
        # 4. Generate Plots
        # =====================================================================
        out_dir = "results_output"
        os.makedirs(out_dir, exist_ok=True)

        plot_paths = generate_all_plots(
            df,
            task_type,
            model,
            X_test,
            y_test,
            feature_names,
            out_dir
        )

        # =====================================================================
        # 5. Generate TXT + HTML + ZIP
        # =====================================================================
        zip_path = generate_report_and_zip(
            text_log=text_log,
            task_type=task_type,
            target_column=target_col,
            plots=plot_paths,
            out_dir=out_dir
        )

        # =====================================================================
        return {
            "message": "AutoML completed successfully.",
            "text": text_log,
            "plots": plot_paths,
            "zip_path": zip_path,
            "task_type": task_type,
            "target": target_col
        }

    except Exception as e:
        return {
            "error": str(e),
            "trace": traceback.format_exc()
        }
