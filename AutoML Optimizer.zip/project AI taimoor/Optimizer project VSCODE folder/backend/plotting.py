import os
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


# ------------------------------------------------------------
# Main plotting function (classification + regression)
# ------------------------------------------------------------
def generate_all_plots(df, task_type, model, X_test, y_test, feature_names, out_dir):

    ensure_dir(out_dir)

    plot_files = []

    # --------------------------------------------------------
    # 1. TARGET DISTRIBUTION
    # --------------------------------------------------------
    plt.figure(figsize=(5,4))
    sns.histplot(df[df.columns[-1]], kde=True)
    plt.title("Target Distribution")
    p = os.path.join(out_dir, "target_distribution.png")
    plt.savefig(p)
    plt.close()
    plot_files.append(p)

    # --------------------------------------------------------
    # 2. CORRELATION HEATMAP
    # --------------------------------------------------------
    plt.figure(figsize=(8,6))
    sns.heatmap(df.corr(numeric_only=True), cmap="coolwarm")
    plt.title("Correlation Heatmap")
    p = os.path.join(out_dir, "correlation.png")
    plt.savefig(p)
    plt.close()
    plot_files.append(p)

    # --------------------------------------------------------
    # MODEL-SPECIFIC PLOTS
    # --------------------------------------------------------

    preds = model.predict(X_test)

    # ============= Classification Plots ======================
    if task_type == "classification" and len(np.unique(y_test)) <= 20:

        # Confusion Matrix
        from sklearn.metrics import confusion_matrix

        cm = confusion_matrix(y_test, preds)

        plt.figure(figsize=(5,4))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
        plt.title("Confusion Matrix")
        p = os.path.join(out_dir, "confusion_matrix.png")
        plt.savefig(p)
        plt.close()
        plot_files.append(p)

        # Feature Importance Bar Chart (if available)
        if hasattr(model, "feature_importances_"):
            imp = model.feature_importances_
            idx = np.argsort(imp)[::-1][:10]

            plt.figure(figsize=(6,4))
            plt.barh(np.array(feature_names)[idx], imp[idx])
            plt.title("Top 10 Features")
            plt.gca().invert_yaxis()
            p = os.path.join(out_dir, "feature_importance.png")
            plt.savefig(p)
            plt.close()
            plot_files.append(p)

    # ============= Regression Plots ==========================
    elif task_type == "regression":

        # Predicted vs actual
        plt.figure(figsize=(5,4))
        plt.scatter(y_test, preds, s=10)
        plt.xlabel("Actual")
        plt.ylabel("Predicted")
        plt.title("Predicted vs Actual")
        p = os.path.join(out_dir, "pred_vs_actual.png")
        plt.savefig(p)
        plt.close()
        plot_files.append(p)

        # Residuals
        residuals = y_test - preds
        plt.figure(figsize=(5,4))
        sns.histplot(residuals, kde=True)
        plt.title("Residual Distribution")
        p = os.path.join(out_dir, "residuals.png")
        plt.savefig(p)
        plt.close()
        plot_files.append(p)

        # Feature importance (RF or XGB)
        if hasattr(model, "feature_importances_"):
            imp = model.feature_importances_
            idx = np.argsort(imp)[::-1][:10]

            plt.figure(figsize=(6,4))
            plt.barh(np.array(feature_names)[idx], imp[idx])
            plt.title("Top 10 Features")
            plt.gca().invert_yaxis()
            p = os.path.join(out_dir, "feature_importance.png")
            plt.savefig(p)
            plt.close()
            plot_files.append(p)

    return plot_files
